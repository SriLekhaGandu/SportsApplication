package com.example.hi_pc.soccerapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class FavouriteDBHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "favouriteDatabase.db";

    public FavouriteDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void drop(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS SportTeamDetails");
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String CREATE_TABLE = "CREATE TABLE "
                + FavouriteContract.FavouriteContractEntry.TABLE_NAME + " ( "
                + FavouriteContract.FavouriteContractEntry.COLUMN_POSTER_PATH + " TEXT , "
                + FavouriteContract.FavouriteContractEntry.COLUMN_TITLE + " TEXT  , "
                + FavouriteContract.FavouriteContractEntry.COLUMN_ALSO_KNOWN_AS + " TEXT  , "
                + FavouriteContract.FavouriteContractEntry.COLUMN_MANAGER + " TEXT  , "
                + FavouriteContract.FavouriteContractEntry.COLUMN_COUNTRY + " TEXT  , "
                + FavouriteContract.FavouriteContractEntry.COLUMN_WEBSITE + " TEXT  , "
                + FavouriteContract.FavouriteContractEntry.COLUMN_YEAR + " TEXT  , "
                + FavouriteContract.FavouriteContractEntry.COLUMN_NEWS + " TEXT, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_ID + " TEXT PRIMARY KEY" + ");";
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + FavouriteContract.FavouriteContractEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

}
