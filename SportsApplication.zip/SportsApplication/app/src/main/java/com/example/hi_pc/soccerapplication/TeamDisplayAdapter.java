package com.example.hi_pc.soccerapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class TeamDisplayAdapter extends RecyclerView.Adapter<TeamDisplayAdapter.TeamsDataHolder> {
    ArrayList<TeamsPojo> teamData;
    Context mContext;

    public TeamDisplayAdapter(TeamsDisplayActivity teamsDisplayActivity, ArrayList<TeamsPojo> teamData) {
        this.teamData = teamData;
        this.mContext = teamsDisplayActivity;
    }

    @Override
    public TeamDisplayAdapter.TeamsDataHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        int id = R.layout.item_list;
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View movieView = inflater.inflate(id, parent, false);
        TeamsDataHolder TeamsDataHolder = new TeamsDataHolder(movieView);
        return TeamsDataHolder;
    }

    @Override
    public void onBindViewHolder(TeamDisplayAdapter.TeamsDataHolder holder, int position) {
        Picasso.with(mContext).load(teamData.get(position).getLogo()).placeholder(R.drawable.sports).into(holder.logoView);
        holder.teamName.setText(teamData.get(position).getTeamName());
    }

    @Override
    public int getItemCount() {
        return teamData.size();
    }

    public class TeamsDataHolder extends RecyclerView.ViewHolder {
        ImageView logoView;
        TextView teamName;

        public TeamsDataHolder(final View itemView) {
            super(itemView);
            teamName = (TextView) itemView.findViewById(R.id.team_name);
            logoView = (ImageView) itemView.findViewById(R.id.team_logo);
            logoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(mContext, teamData.get(getAdapterPosition()).getTeamId(), Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(mContext, TeamsDetailsDisplayActivity.class);
                    intent.putExtra(itemView.getResources().getString(R.string.Data), teamData);
                    intent.putExtra(itemView.getResources().getString(R.string.Position), getAdapterPosition());
                    mContext.startActivity(intent);
                }
            });
        }
    }
}
