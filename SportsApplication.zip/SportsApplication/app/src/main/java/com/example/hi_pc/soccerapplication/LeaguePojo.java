package com.example.hi_pc.soccerapplication;

import android.os.Parcel;
import android.os.Parcelable;

public class LeaguePojo implements Parcelable {
    public static final Creator<LeaguePojo> CREATOR = new Creator<LeaguePojo>() {
        @Override
        public LeaguePojo createFromParcel(Parcel in) {
            return new LeaguePojo(in);
        }

        @Override
        public LeaguePojo[] newArray(int size) {
            return new LeaguePojo[size];
        }
    };
    String leagueName;
    String sport;
    String id;

    public LeaguePojo(String leagueName, String sport, String id) {
        this.leagueName = leagueName;
        this.sport = sport;
        this.id = id;
    }

    protected LeaguePojo(Parcel in) {
        leagueName = in.readString();
        sport = in.readString();
        id = in.readString();
    }

    public String getLeagueName() {
        return leagueName;
    }

    public void setLeagueName(String leagueName) {
        this.leagueName = leagueName;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(leagueName);
        parcel.writeString(sport);
        parcel.writeString(id);
    }
}
