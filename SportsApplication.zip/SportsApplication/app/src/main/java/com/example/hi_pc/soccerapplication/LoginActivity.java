package com.example.hi_pc.soccerapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LoginActivity extends AppCompatActivity {

    @BindView(R.id.user_name)
    EditText userName;
    @BindView(R.id.register)
    TextView registerHere;
    @BindView(R.id.password)
    EditText password;
    @BindView(R.id.id_login)
    Button login;
    @BindView(R.id.cancel)
    Button cancel;
    @BindView(R.id.linear_layout)
    LinearLayout linearLayout;
    Snackbar snackbar;
    SharedPreferences sharedPreferences;
    FirebaseAuth auth;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        sharedPreferences = getApplicationContext().getSharedPreferences("MyPref", 0);
        editor = sharedPreferences.edit();
        editor.apply();
        if (sharedPreferences.contains(getResources().getString(R.string.LOGGED))) {
            if (sharedPreferences.getBoolean(getResources().getString(R.string.LOGGED), false)) {
                Intent intent = new Intent(getApplicationContext(), SportsActivity.class);
                finish();
                startActivity(intent);
            }
        }
        auth = FirebaseAuth.getInstance();
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (userName.getText().length() == 0) {
                    userName.setError(getResources().getString(R.string.error_message));
                } else {
                    if (password.getText().length() == 0) {
                        password.setError(getResources().getString(R.string.error_message));
                    } else {
                        if (checkOnline())
                            retrievefromDatabase();
                        else
                            Toast.makeText(LoginActivity.this, getResources().getString(R.string.No_Internet), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userName.setText("");
                password.setText("");
            }
        });
        registerHere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                finish();
                startActivity(intent);
            }
        });
    }

    private void retrievefromDatabase() {
        auth.signInWithEmailAndPassword(userName.getText().toString(), password.getText().toString())
                .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()) {
                            editor.putBoolean(getResources().getString(R.string.LOGGED), false);
                            editor.commit();
                            Toast.makeText(LoginActivity.this, R.string.auth_failed, Toast.LENGTH_LONG).show();
                        } else {
                            editor.putBoolean(getResources().getString(R.string.LOGGED), true);
                            editor.commit();
                            Intent intent = new Intent(LoginActivity.this, SportsActivity.class);
                            finish();
                            startActivity(intent);
                        }
                    }
                });
    }

    public boolean checkOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null)
            return true;
        else
            return false;
    }
}