package com.example.hi_pc.soccerapplication;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.widget.RemoteViews;

public class MySportsWidget extends AppWidgetProvider {
    static String text = "";

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {
        Cursor cursor = null;
        SharedPreferences sharedPreferences;
        SharedPreferences.Editor editor;

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.my_sports_widget);
        Intent intent = new Intent(context, SportsActivity.class);
        sharedPreferences = context.getSharedPreferences("MyPref", 0);
        if (!sharedPreferences.getBoolean(context.getResources().getString(R.string.LOGGED), false)) {
            views.setTextViewText(R.id.appwidget_text, "User Logged offf");
            appWidgetManager.updateAppWidget(appWidgetId, views);
        } else {
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
            views.setOnClickPendingIntent(R.id.appwidget_text, pendingIntent);
            cursor = context.getContentResolver().query(FavouriteContract.CONTENT_URI, null, null, null, null);
            text="";
            while (cursor.moveToNext()) {
                text = text + "\n" + cursor.getString(1);
            }        // Instruct the widget manager t// o update the widget
            cursor.close();
            if (text.equals("")) {
                views.setTextViewText(R.id.appwidget_text, context.getResources().getString(R.string.NoFavourites));
                appWidgetManager.updateAppWidget(appWidgetId, views);

            } else {
                views.setTextViewText(R.id.appwidget_text, text);
                appWidgetManager.updateAppWidget(appWidgetId, views);
            }
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }
}

