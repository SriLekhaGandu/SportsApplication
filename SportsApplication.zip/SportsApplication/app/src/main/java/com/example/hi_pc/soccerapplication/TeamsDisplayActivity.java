package com.example.hi_pc.soccerapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class TeamsDisplayActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks {
    public static final String KEY = "key";
    public static final String POSITION = "position";
    ProgressDialog dialog;
    LeaguePojo leaguePojo;
    String title;
    TeamDisplayAdapter teamDisplayAdapter;
    GridLayoutManager gridLayoutManager;
    RecyclerView recyclerView;
    String value;
    Snackbar snackbar;
    LinearLayout linearLayout;
    ArrayList<TeamsPojo> teamsPojoList;
    private int scrollPosition = 0;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialog.isShowing())
            dialog.dismiss();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (dialog.isShowing())
            dialog.dismiss();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teams_display);
        dialog = new ProgressDialog(this);
        recyclerView = (RecyclerView) findViewById(R.id.soccer_recycler_view);
        gridLayoutManager = new GridLayoutManager(this, 2);
        linearLayout = (LinearLayout) findViewById(R.id.team_linear);

        Bundle bundle = getIntent().getExtras();
        if (savedInstanceState != null)
            scrollPosition = savedInstanceState.getInt(POSITION);
        if (bundle != null) {
            if (bundle.containsKey(getResources().getString(R.string.fav))) {
                getSupportLoaderManager().restartLoader(10, null, this);
                value = "Fav";
            } else {
                title = bundle.getString(getResources().getString(R.string.myString));
                leaguePojo = bundle.getParcelable(getResources().getString(R.string.Data));
                String teamUrl = leaguePojo.getLeagueName().replace(" ", "%20");
                value = "Teams";
                teamUrl = getResources().getString(R.string.teamurl) + teamUrl;
                if (checkOnline()) {
                    SoccerAsyncTask soccerAsyncTask = new SoccerAsyncTask(teamUrl);
                    soccerAsyncTask.execute();
                } else
                    setSnackBar();
            }
        }
    }

    public void setSnackBar() {
        snackbar = Snackbar.make(linearLayout, getResources().getString(R.string.NoInternet), Snackbar.LENGTH_INDEFINITE)
                .setAction(getResources().getString(R.string.RETRY), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        retry();
                    }
                });
        snackbar.setActionTextColor(Color.RED);
        View view = snackbar.getView();
        TextView tv = (TextView) view.findViewById(android.support.design.R.id.snackbar_text);
        tv.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(KEY, value);
        if ((!getSupportLoaderManager().hasRunningLoaders() || (!dialog.isShowing())) && (checkOnline())) {
            scrollPosition = gridLayoutManager.findFirstVisibleItemPosition();
            outState.putInt(POSITION, scrollPosition);
        }
    }

    public boolean checkOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null)
            return true;
        else
            return false;
    }

    private void retry() {
        Intent intent = new Intent(TeamsDisplayActivity.this, TeamsDisplayActivity.class);
        finish();
        startActivity(intent);
    }

    @Override
    public Loader onCreateLoader(int id, Bundle bundle) {
        return new AsyncTaskLoader<String>(this) {
            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
            }

            @Override
            public String loadInBackground() {
                Cursor cursor;
                teamsPojoList = new ArrayList<TeamsPojo>();
                cursor = getContentResolver().query(FavouriteContract.CONTENT_URI, null, null, null, null);
                while (cursor.moveToNext()) {
                    TeamsPojo teamsPojo = new TeamsPojo(cursor.getString(1), cursor.getString(8), cursor.getString(2), " ", cursor.getString(6), cursor.getString(7), cursor.getString(3), cursor.getString(0), cursor.getString(5), cursor.getString(4));
                    teamsPojoList.add(teamsPojo);
                }
                cursor.close();
                return null;
            }
        };
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (value == "Fav") {
            getSupportLoaderManager().restartLoader(10, null, this);
        }
    }

    @Override
    public void onLoadFinished(Loader loader, Object o) {
        if (teamsPojoList.size() > 0) {
            teamDisplayAdapter = new TeamDisplayAdapter(TeamsDisplayActivity.this, teamsPojoList);
            recyclerView.setLayoutManager(gridLayoutManager);
            recyclerView.setAdapter(teamDisplayAdapter);
            recyclerView.scrollToPosition(scrollPosition);

        } else {
            AlertDialog.Builder alert = new AlertDialog.Builder(TeamsDisplayActivity.this);
            alert.setMessage(R.string.Message).setTitle(R.string.NoFavourites);
            alert.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    Intent intent = new Intent(TeamsDisplayActivity.this, SportsActivity.class);
                    startActivity(intent);
                }
            });
            AlertDialog dialog = alert.create();
            dialog.show();
        }
    }

    @Override
    public void onLoaderReset(Loader loader) {

    }

    public class SoccerAsyncTask extends AsyncTask<String, Void, String> {
        String teamString;

        public SoccerAsyncTask(String s) {
            this.teamString = s;
        }

        @Override
        protected void onPreExecute() {
            dialog.setMessage(getResources().getString(R.string.Loading));
            dialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
            teamDisplayAdapter = new TeamDisplayAdapter(TeamsDisplayActivity.this, teamsPojoList);
            recyclerView.setLayoutManager(gridLayoutManager);
            recyclerView.setAdapter(teamDisplayAdapter);
            recyclerView.scrollToPosition(scrollPosition);
        }

        @Override
        protected String doInBackground(String... strings) {
            URL teamUrl = null;
            String poster_response = "";
            GetDetailsURL connect = new GetDetailsURL();
            try {
                teamUrl = connect.buildUrl(teamString);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            String teamResponse = null;
            int i = 0;
            teamResponse = connect.getDetailsResponse(teamUrl);
            teamsPojoList = new ArrayList<TeamsPojo>();
            try {
                JSONObject teamObject = new JSONObject(teamResponse);
                JSONArray teamArray = teamObject.getJSONArray(getResources().getString(R.string.teams));
                while (i < teamArray.length()) {
                    JSONObject team = teamArray.getJSONObject(i);
                    String name = team.getString(getResources().getString(R.string.teamName));
                    String id = team.getString(getResources().getString(R.string.teamId));
                    String shortName = team.getString(getResources().getString(R.string.shortName));
                    String altName = team.getString(getResources().getString(R.string.altName));
                    String formedYear = team.getString(getResources().getString(R.string.year));
                    String news = team.getString(getResources().getString(R.string.news));
                    String logo = team.getString(getResources().getString(R.string.logo));
                    String manager = team.getString(getResources().getString(R.string.manager));
                    String website = team.getString(getResources().getString(R.string.website));
                    String country = team.getString(getResources().getString(R.string.country));
                    TeamsPojo teamsPojo = new TeamsPojo(name, id, shortName, altName, formedYear, news, manager, logo, website, country);
                    teamsPojoList.add(teamsPojo);
                    i++;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return poster_response;
        }
    }

}
