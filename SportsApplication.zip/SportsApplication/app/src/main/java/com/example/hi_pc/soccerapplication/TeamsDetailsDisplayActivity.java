package com.example.hi_pc.soccerapplication;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TeamsDetailsDisplayActivity extends AppCompatActivity {
    TextView name, otherName, news, manager, country, website, year;
    ArrayList<TeamsPojo> teamsPojoList;
    TeamsPojo teamsPojo;
    ImageView logo;
    int flag;
    FloatingActionButton fab;
    SQLiteDatabase sqLiteDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teams_details_display);
        name = (TextView) findViewById(R.id.name);
        teamsPojoList = getIntent().getExtras().getParcelableArrayList(getResources().getString(R.string.Data));
        int pos = getIntent().getExtras().getInt(getResources().getString(R.string.Position));
        teamsPojo = teamsPojoList.get(pos);
        name.setText(teamsPojo.getTeamName());
        otherName = (TextView) findViewById(R.id.other_names);
        if (!teamsPojo.getTeamShortName().equals("null")) {
            otherName.append(teamsPojo.getTeamShortName());
            if (!teamsPojo.getTeamShortName().equals("")) {
                otherName.append("," + teamsPojo.getAlternateName());
            }
        } else {
            if (!teamsPojo.getAlternateName().equals("")) {
                otherName.append(teamsPojo.getAlternateName());
            } else
                otherName.append(getResources().getString(R.string.NOdata));
        }
        country = (TextView) findViewById(R.id.country);
        if (teamsPojo.getcountry().isEmpty())
            country.append(getResources().getString(R.string.NOdata));
        else
            country.append(teamsPojo.getcountry());
        manager = (TextView) findViewById(R.id.manager);
        if (teamsPojo.getManager().isEmpty())
            manager.append( getResources().getString(R.string.NOdata));
        else
            manager.append(teamsPojo.getManager());
        website = (TextView) findViewById(R.id.website);
        if (!teamsPojo.getWebsite().isEmpty())
            website.append(teamsPojo.getWebsite());
        else
            website.append(getResources().getString(R.string.NOdata));
        news = (TextView) findViewById(R.id.news);
        if (!teamsPojo.getNews().isEmpty())
            news.setText(teamsPojo.getNews());
        else
            news.append(getResources().getString(R.string.NOdata));
        year = (TextView) findViewById(R.id.year);
        if (teamsPojo.getFormedYear().isEmpty())
            year.append(getResources().getString(R.string.NOdata));
        else
            year.append(teamsPojo.getFormedYear());
        AdView mAdView;
        mAdView = findViewById(R.id.banner);
        MobileAds.initialize(this, "ca-app-pub-6336523906622902~6817819328");
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice("C3528C0925D3AB8424433F9070BD2A5F")
                .build();
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading Data");
        progressDialog.show();
        mAdView.loadAd(adRequest);
        progressDialog.dismiss();
        final FavouriteDBHelper dbHelper = new FavouriteDBHelper(this);
        sqLiteDatabase = dbHelper.getWritableDatabase();
        logo = (ImageView) findViewById(R.id.image_logo);
        Picasso.with(getApplicationContext()).load(teamsPojo.getLogo()).placeholder(R.drawable.football).into(logo);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        Uri uri = FavouriteContract.CONTENT_URI;
        Uri myUri = uri.buildUpon().appendPath(teamsPojo.getTeamId()).build();
        Cursor cursor = getContentResolver().query(myUri, null, null, null, null);
        if (cursor.getCount() > 0) {
            fab.setImageResource(R.drawable.checked);
            flag = 1;
        } else {
            flag = 0;
        }
        cursor.close();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (flag == 0) {
                    fab.setImageResource(R.drawable.checked);
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_NEWS, teamsPojo.getNews());
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_POSTER_PATH, teamsPojo.getLogo());
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_TITLE, teamsPojo.getTeamName());
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_WEBSITE, teamsPojo.getWebsite());
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_YEAR, teamsPojo.getFormedYear());
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_ALSO_KNOWN_AS, teamsPojo.getAlternateName() + " " + teamsPojo.getTeamShortName());
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_COUNTRY, teamsPojo.getcountry());
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_ID, teamsPojo.getTeamId());
                    contentValues.put(FavouriteContract.FavouriteContractEntry.COLUMN_MANAGER, teamsPojo.getManager());
                    Uri uri = getContentResolver().insert(FavouriteContract.CONTENT_URI, contentValues);
                    if (uri != null) {
                        Toast.makeText(getApplicationContext(), uri.toString(), Toast.LENGTH_SHORT).show();
                    }
                    flag = 1;
                } else {
                    fab.setImageResource(R.drawable.unchecked);
                    flag = 0;
                    String stringid = teamsPojo.getTeamId();
                    Uri uri = FavouriteContract.CONTENT_URI;
                    int res = getContentResolver().delete(uri, stringid, null);
                }
            }
        });
    }
}