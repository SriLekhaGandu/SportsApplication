package com.example.hi_pc.soccerapplication;

import android.os.Parcel;
import android.os.Parcelable;


public class TeamsPojo implements Parcelable {
    public static final Creator<TeamsPojo> CREATOR = new Creator<TeamsPojo>() {
        @Override
        public TeamsPojo createFromParcel(Parcel in) {
            return new TeamsPojo(in);
        }

        @Override
        public TeamsPojo[] newArray(int size) {
            return new TeamsPojo[size];
        }
    };
    String teamName;
    String teamId;
    String teamShortName;
    String alternateName;
    String formedYear;
    String news;
    String manager;
    String logo;
    String website;
    String country;

    protected TeamsPojo(Parcel in) {
        teamName = in.readString();
        teamId = in.readString();
        teamShortName = in.readString();
        alternateName = in.readString();
        formedYear = in.readString();
        news = in.readString();
        manager = in.readString();
        logo = in.readString();
        website = in.readString();
        country = in.readString();
    }

    public TeamsPojo(String teamName, String teamId, String teamShortName, String alternateName, String formedYear, String news, String manager, String logo, String website, String country) {

        this.teamName = teamName;
        this.teamId = teamId;
        this.teamShortName = teamShortName;
        this.alternateName = alternateName;
        this.formedYear = formedYear;
        this.news = news;
        this.manager = manager;
        this.logo = logo;
        this.website = website;
        this.country = country;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getTeamId() {
        return teamId;
    }

    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }

    public String getTeamShortName() {
        return teamShortName;
    }

    public void setTeamShortName(String teamShortName) {
        this.teamShortName = teamShortName;
    }

    public String getAlternateName() {
        return alternateName;
    }

    public void setAlternateName(String alternateName) {
        this.alternateName = alternateName;
    }

    public String getFormedYear() {
        return formedYear;
    }

    public void setFormedYear(String formedYear) {
        this.formedYear = formedYear;
    }

    public String getNews() {
        return news;
    }

    public void setNews(String news) {
        this.news = news;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getcountry() {
        return country;
    }

    public void setcountry(String country) {
        this.country = country;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(teamName);
        parcel.writeString(teamId);
        parcel.writeString(teamShortName);
        parcel.writeString(alternateName);
        parcel.writeString(formedYear);
        parcel.writeString(news);
        parcel.writeString(manager);
        parcel.writeString(logo);
        parcel.writeString(website);
        parcel.writeString(country);
    }
}
